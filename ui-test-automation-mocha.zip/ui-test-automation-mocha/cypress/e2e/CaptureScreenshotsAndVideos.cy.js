describe('mysuite',()=>{

    it('Capture Screenshots and Videos',()=>{
        cy.visit("https://demo.opencart.com.gr/");
        cy.screenshot("homepage");
        cy.wait(5000);
        cy.get("img[title='Your Store']").screenshot("logo");

        //Automatically Capture Screenshot & Video on failure - only when on execute through CLI

        cy.get("li:nth-child(7) a:nth-child(1)").click();
        cy.get("div[id='content'] h2").should('have.text',"Tablets");
    })
})